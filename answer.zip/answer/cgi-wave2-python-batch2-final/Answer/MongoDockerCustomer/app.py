from flask import Flask, request
from flask_restful import Resource, Api, reqparse
from pymongo import MongoClient
from bson import ObjectId
from flask_cors import CORS

app = Flask(__name__)
CORS(app)
api = Api(app)

client = MongoClient('mongodb://db:27017/')
db = client.customers_db
customers = db.customers

parser = reqparse.RequestParser()
parser.add_argument('customerId', type=int, required=True,
                    help='Id cannot be blank')
parser.add_argument('customerName', type=str, required=True,
                    help='customerName cannot be blank')
parser.add_argument('customerMobile', type=str, required=True,
                    help='customerMobile cannot be blank')
parser.add_argument('customerAddress', type=str, required=True,
                    help='customerPrice cannot be blank')

def customer_exists(customerId):
    existing_customer = customers.find_one({"customerId": customerId})
    return existing_customer is not None

class CustomerResource(Resource):
    def get(self):
        all_customers = list(customers.find())
        for customer in all_customers:
            customer['_id'] = str(customer['_id'])
        return all_customers, 200

    def post(self):
        args = parser.parse_args()
        customer_id = args["customerId"]

        if customer_exists(customer_id):
            return {"message": f"Customer with customerId {customer_id} already exists"}, 409

        result = customers.insert_one({"customerId": args["customerId"], "customerName": args["customerName"], "customerMobile": args["customerMobile"], "customerAddress": args["customerAddress"]})
        return {"id": str(result.inserted_id), "customerId": args["customerId"], "customerName": args["customerName"], "customerMobile": args["customerMobile"], "customerAddress": args["customerAddress"]}, 201

    


api.add_resource(CustomerResource, '/customer')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
